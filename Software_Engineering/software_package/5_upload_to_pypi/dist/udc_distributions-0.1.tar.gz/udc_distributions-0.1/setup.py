from setuptools import setup

setup(name='udc_distributions',
      version='0.1',
      description='Vince UDC Gaussian distributions Practice',
      packages=['udc_distributions'],
      zip_safe=False)
